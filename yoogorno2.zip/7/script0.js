var lastslidenum=[]
var safeid=""
var thisshape=""
var onceshape=[]
var before_slide=[]
var shuffledvector=[]               
var shuffledvectorbeg=0, shuffledvectorend=0
var anscrw=['нет','ЗВЕЗДЫ','НЕБО','ГРОМ','ВЕТЕР','МОЛНИЯ','ЛУНА','ОБЛАКО','ДОЖДЬ','ОГОНЬ','ТУЧА'];
function getURLParameter(name) {
  return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1].replace(/\+/g, '%20')) || null;
}

function getRandomInRange(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}


function anew(a=1){
	if (a!=1 ) {
		var ok = confirm("Вы действительно хотите начать всё заново?");
	} else ok=true;
	if (ok) document.location.replace("index.html");
}

function startgame() {
if (safeid>"") initsafe(safeid);
$('#slide1').hide()
console.log('s=', getURLParameter('s'));
if(getURLParameter('s')) toslide(0,getURLParameter('s'),2); else toslide(0,2,1);
}

function returnslide(f,op="") {
var t=0;
if (lastslidenum.length>0){
	if(op=="next"){
	  t=lastslidenum.pop();
          $('#slide'+f).hide()	
	  toslide(op,t,t);
        }
        else  {
	        $('#slide'+f).hide()	
	        $('#slide'+lastslidenum.pop()).show()	
        }
}
}

function SlidesShuffle(a=0,b=0){
	if(a==0 || b==0) {
	  shuffledvector=[];
	  shuffledvectorbeg=0;	
	  shuffledvectorend=0;
	  return;               
	}
   	var j;
	shuffledvectorbeg=b;	
	shuffledvectorend=a;
	for (var i=a;i <=b;i++){
      		j= getRandomInRange(a,i)
      		shuffledvector[i]=shuffledvector[j]
      		shuffledvector[j]=i
	}
}

function enterShuffled(){
 	 if (shuffledvectorend>shuffledvectorbeg){
		var t=shuffledvectorend;
		shuffledvectorend=shuffledvectorbeg;
		shuffledvectorbeg=t;
	}
}


function toslide(el,t,f) {
	lastslidenum.push(f);
	$('#slide'+f).hide()
	if (el=="pred")
	   if(t-1==shuffledvectorend) t=shuffledvector[t-1]; 
	   else {
 	   	var p=shuffledvector.indexOf(t);
		if(p==-1) t=t-1;
		else if (p==shuffledvectorbeg)t=p-1;
		else t=shuffledvector[p-1]; 
	}
	if (el=="next"){
	   if (shuffledvectorend<shuffledvectorbeg){
		   if(t+1==shuffledvectorend) {
			shuffledvectorend=shuffledvectorbeg;
			shuffledvectorbeg=t+1;
			t=shuffledvector[t+1]; 
		   }		
	   }else{
 	   	var p=shuffledvector.indexOf(t);
		if(p==-1) t=t+1;
		else if (p==shuffledvectorend)t=p+1;
		else t=shuffledvector[p+1]; 
		}
	}
	if (typeof (before_slide[t])=== "function") before_slide[t]();
	$('#slide'+t).show()	
}

function gotolocalurl(t){
    var k=t.indexOf("//");
    t=t.slice(k+2)
     var s=document.location.href
     k=s.lastIndexOf("/")
     s=s.substr(0,k+1)+t;
    window.open(s, '_blank').focus();

}

function gotourl(t,f) {
   if(f) 
    window.open(t, '_blank').focus();
   else 
    document.location.replace(t);	
}

function hideShape(s,cl=false){
if(cl) $('.'+s).hide();else $('#'+s).hide();
}

function showShape(s,cl=false){
if(cl) $('.'+s).show();else $('#'+s).show();
}

function unicode(s){
 var  sAscii, ascval
  sAscii = ''
  for (var x = 0; x<s.length;x++){
    ascval = s.charCodeAt(x)
    if (ascval < 0)   ascval = 65536 + ascval; 
    sAscii = sAscii+'&#'+ ascval+';'
  }
  return sAscii;
}

function Npadezh(k,s1,s2,s3){
if(k>=5 && k<20) return s3;
if (k%10==1) return s1;
if (k%10==2 || k%10==3 || k%10==4) return s2;
return s3;
}


function borderShape(s,b="green solid 6px"){
$('#'+s).css('border',b);
}



function onceClick(s){
	if (onceshape.indexOf(s)>=0) {
		return false;
	}
	onceshape.push(s);
	return true;
}




function initsafe(n){
    $("#"+n).attr('value',"");	
}


function opensafe(s,l,n,sn){

    var w = ""
    var v = s.charCodeAt(l)-65
    var d=0
    for(var  i = 0;i<l;i++){
	d=(s.charCodeAt(i)-65+22-3-v)*3
        w=w+String.fromCharCode((d-4+11)%11+48)
    }
    s=document.getElementById(n).value;
	document.getElementById(n).value="";
    if(s.length==l){
        s=s.replace(/[^0-9]/g, "");
	if(s.length==l){
	        if(s==w) toslide(0,sn+1,sn); 
		else document.getElementById(n+'_error_click').click();

	}
   }
}


function spswap(c1,c2,p=true){
var y1=$('#'+c1)[0].style.top
var y2=$('#'+c2)[0].style.top
$('#'+c1).css('top',y2)
$('#'+c2).css('top',y1)
if(p){
var n1=(Number.parseInt(y1)-8)/9;
var n2=(Number.parseInt(y2)-8)/9;
console.log(n1,n2)
t=arr1[n1]
arr1[n1]=arr1[n2];
arr1[n2]=t;
console.log(arr1[n1],arr1[n2])
if(arr1[n1]==n1){ $('#'+c2).hide();$('#t'+c2.charAt(1)).show();sarr1++ }
if(n1!=n2 && arr1[n2]==n2){ $('#'+c1).hide();$('#t'+c1.charAt(1)).show();sarr1++}
}
}

function fun_runch1(){
if(chsl1==0) { chsl1=thisShape; $('#'+thisShape).css('background-color','red') }
else chsl2=thisShape;
if(chsl1!=0 && chsl2!=0){ spswap(chsl1,chsl2);
$('#'+chsl1).css('background-color','transparent')
$('#'+chsl2).css('background-color','transparent')
chsl1=0; chsl2=0
}
if (sarr1==10) showShape('nextans');
}



function crw_input_control(evn, pattern) {

	evn = evn || window.event;
	var sender = evn.target || evn.srcElement;
	var isIE = document.all;
	var str=sender.value;
	var isize=sender.size;
	if (pattern=='' ) {sender.value='';$('#'+sender.id).attr('value',''); $('#'+sender.id).css('color','black'); 
	$('#'+sender.id).css('text-decoration','none');$('#'+sender.id).attr('placeholder','')
	return;}                                       

	if (sender.tagName.toUpperCase()=='INPUT')
	{
		var keyPress = isIE ? evn.keyCode : evn.which;

		if (keyPress < 32 || evn.altKey || evn.ctrlKey){
                  if(keyPress==13)  {inpword2(anstext.value);return false;}           
			return true;}

	    var symbPress = String.fromCharCode(keyPress);
        	    if (!pattern.test(symbPress))
	    	{$('#'+sender.id).attr('placeholder','А-Яа-я');return false;}

       if (str.length>isize-1) return false;

	}

	return true;

}


 function inpword(sn)
{  var re = /^(\d*)\(по\s(.).*\.\,\s?(\d*).*\)/;
if(sn.id>"") {sn=sn.id;sn=sn.substring(7)} 
console.log('numword'+sn);
var ans=document.getElementById("ans");
s=document.getElementById('numword'+sn).title;
var nameList = s.match(re);
if(document.getElementById('numword'+nameList[1]).className>"") {
$('#anstext').click();
ans.getElementsByTagName('p')[0].innerText="";
document.getElementById("anstext").size=15;
document.getElementById("anstext").value=anscrw[+sn];
ans.hidden=false;
$('#ans').show();


return;

}

var k=s.indexOf(").") 
$('#anstext').click();
ans.getElementsByTagName('p')[0].innerText=s.substr(0,k+1);
document.getElementById("anstext").size=nameList[3];
document.getElementById("anstext").value="";
if(nameList[2]=='в')
document.getElementById("anstext").min=nameList[1];
else
document.getElementById("anstext").min=-nameList[1];

var hint="";
var n1=document.getElementById("anstext").min
var s1=document.getElementById("anstext").size

/*
if(hs[+sn]>=2) {hint=anscrw[+sn].substring(0,1);
for(var i=1;i<=s1-2;i++)hint=hint+"?";
if(hs[+sn]>=5) {
hint="";
for(var i=1;i<=s1-1;i++)
if(i%2==1) hint=hint+anscrw[+sn].substr(i-1,1);
else hint=hint+"?";
}
if(hs[+sn]>=3) hint=hint+anscrw[+sn].substr(s1-1,1)
else  hint=hint+"?";
}
//if(hs[+sn]>=8) {hs[+sn]=8; hint=anscrw[+sn];}
*/

ans.hidden=false;
$('#ans').show();
$('#anstext').attr('placeholder',hint);
document.getElementById("anstext").focus();
}




function inpword2(w,ppp=0)
{  
var chok=false;
w=w.toUpperCase();
w=w.replace('Ё','Е');

var numword=document.getElementById("anstext").min;
if(ppp==-1)numword=-numword; 
//if (Math.abs(numword)==7 && w=="ЭЛИЗА") w=="ЭЛЬЗА"
//if (w>"")hs[Math.abs(numword)]++;
anstext.value=w;
ans.hidden=true;
w=w.trim();
w=w.substring(0,document.getElementById("anstext").size);

var vert=true;
var isize=document.getElementById("anstext").size;

if (w===anscrw[Math.abs(numword)]) {chok=true;
if(Math.abs(numword)<7)  setFlag(Math.abs(numword)-1,25-7);
else setFlag(Math.abs(numword)-7,25-7-1);
}

console.log('nnn','numword'+Math.abs(numword));
if(numword==0||document.getElementById('numword'+Math.abs(numword)).className>"") return;
if (numword<0) {vert=false;numword=-numword;}
var tr2 = document.getElementById('crosw').getElementsByTagName('tr');
var j=0;
var q="-";
if(vert)
for(var i=0;i<isize;i++){
    var c=w.substring(i,i+1).toUpperCase();
    if (c=='Ё') c='Е';
if(c>='а' && c<='я' ||c>='А' && c<='Я' ||c=='ё'||c=='Ё') {  

    	var td2 = tr2[getcoord(numword,0)+j].getElementsByTagName('td');
	var em=td2[0+getcoord(numword,1)].getElementsByTagName('em');
	var st=td2[0+getcoord(numword,1)].getElementsByTagName('strong');	em[0].innerText=c;
	if (em[0].innerText=='') td2[0+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em></em>'+c;
	else if (st[0].innerText=='') td2[0+getcoord(numword,1)].innerHTML='<em>'+em[0].innerHTML+'</em><strong></strong>'+c;
	else if (st[0].innerText!=em[0].innerText) {td2[0+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em><span>'+c+'</span>';q='';}
	else td2[0+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em>'+c;


	j=j+1;q=q+c;}
if(chok)
{document.getElementById('numword'+numword).className='numwordsel'; 
}else document.getElementById('numword'+numword).className=''; 
}
else 
for(var i=0;i<isize;i++){
    var c=w.substring(i,i+1).toUpperCase();
    if (c=='Ё') c='Е';
if(c>='а' && c<='я' ||c>='А' && c<='Я' ||c=='ё'||c=='Ё') {  
var td2 = tr2[getcoord(numword,0)].getElementsByTagName('td');    	
	var em=td2[j+getcoord(numword,1)].getElementsByTagName('em');
	var st=td2[j+getcoord(numword,1)].getElementsByTagName('strong');
	st[0].innerText=c;
	if (em[0].innerText=='') td2[j+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em></em>'+c;
	else if (st[0].innerText=='') td2[j+getcoord(numword,1)].innerHTML='<em>'+em[0].innerHTML+'</em><strong></strong>'+c;
	else if (st[0].innerText!=em[0].innerText) {td2[j+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em><span>'+c+'</span>';q='';}
	else td2[j+getcoord(numword,1)].innerHTML='<strong>'+st[0].innerHTML+'</strong><em>'+em[0].innerHTML+'</em>'+c;

	j=j+1;q=q+c;} 
if(chok)
{document.getElementById('numword'+numword).className='numwordsel'; 
}else document.getElementById('numword'+numword).className=''; 
}
if(chok){
document.getElementById('numword'+numword).className='numwordsel'; 
p10++;


if(p10==10) {showShape("ret3"); hideShape("ret2"); hideShape("link65");showShape("link64")} 
else {hideShape("ret3"); showShape("ret2"); showShape("link65"); hideShape("link64")
} 



}
else document.getElementById('numword'+numword).className=''; 
}	     

function getcoord(n,d){
var dstr=document.getElementById("poswords").innerHTML.trim()
return dstr.charCodeAt(2*parseInt(n)-1+d)-64
}

function field_input_control(evn, pattern) {

	evn = evn || window.event;
	var sender = evn.target || evn.srcElement;
	var isIE = document.all;
	var str=sender.value;
	var chr;
	var isize=sender.size;
	if($('#'+sender.id).attr('readonly')) return;
	if (pattern=='' ) {sender.value='';$('#'+sender.id).attr('value',''); $('#'+sender.id).css('color','black'); 
	$('#'+sender.id).css('text-decoration','none');$('#'+sender.id).attr('placeholder','')
	return;}                                       
	if (sender.tagName.toUpperCase()=='INPUT')
	{
		var keyPress = isIE ? evn.keyCode : evn.which;

		if (keyPress < 32 || evn.altKey || evn.ctrlKey){
			return false;}

	    var symbPress = String.fromCharCode(keyPress);

	    if (!pattern.test(symbPress))
	    	{$('#'+sender.id).attr('placeholder','А-Яа-я');return false;}

       if (str.length>isize-1) return false;

	chr=symbPress.toUpperCase();
	if (chr==='Ё') chr='Е';
	sender.value=sender.value.toUpperCase()+chr;
	var fg='';
        $('#'+sender.id).attr('value',sender.value)
        $('#'+sender.id).css('color','black')
	$('#'+sender.id).css('text-decoration','none');
	return false;
      }

}

function change_input_control(evn) {

	evn = evn || window.event;
	var sender = evn.target || evn.srcElement;
	var isIE = document.all;
	var str=sender.value;
	var isize=sender.size;
        sender.value=$('#'+sender.id).attr('value').toUpperCase()

        $('#'+sender.id).attr('value',sender.value)

	return true;

}









var cmnval=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

function checkCommonArr() {
for (let i = 0; i < 20; i++)
  if(cmnval[i]!=0) return true;
return false;
}
 
function CreateCommonArr(str) {
//str=formatNumbersToString(secondArray)+formatNumbersToString(thirdArray) +s
if(!str) return false;
    if (str.length !=65) return false;
 
  var  s = parseInt(str.slice(-5), 10);
//console.log("s=",s)
    if(isNaN(s)) return false;
    else s=(s*59387)%100000;
//console.log("s=",s)
     str = str.slice(0, -5);
 
    if (str.length % 2 !== 0 || str.length<60) {
        return false;    
    }
      
    const halfLength = 20;//str.length / 3;
    const firstHalf = str.substring(0, halfLength);
    const secondHalf = str.substring(20);
    
    // Функция для разделения строки на подстроки по 2 символа и преобразования в числа
     const splitToNumbers = (substr) => {
        const result = [];
        var x=0;  
        for (let i = 0; i < substr.length; i += 2) {
            const twoDigit = substr.substring(i, i + 2);
            x=parseInt(twoDigit, 10);
            if(isNaN(x)) return [];
            result.push(x);
        }
        return result;
    };
var x=0;    
var  secondArray = splitToNumbers(firstHalf);
var thirdArray = splitToNumbers(secondHalf);
    if(secondArray.length==0 || thirdArray.length==0) return false;
    cmnval= [];
for (let i = 0; i < 20; i++) {
    cmnval.push((100+thirdArray[i] - secondArray[i%10])%100);
    x=x+cmnval [i]+secondArray[i%10];
}
//console.log(x,s)
return x==s;
 
} 


function formatNumbersToString(arr) {
    return arr.map(num => {
        // Преобразуем число в строку и дополняем слева нулем до 2 символов
        return num.toString().padStart(2, '0');
    }).join('');
}

var level=0;
var S=getURLParameter('idtmp'); 
history.pushState(null, null, "?idtmp=0") ;
console.log(CreateCommonArr(S));
if(CreateCommonArr(S)) {window.onload=function(){
console.log(S)
if(checkFlag(7)){
    var q = confirm("Вы хотите начать чтение 7-й главы заново?\nОК - Да, заново; ОТМЕНА - Нет, продолжить чтение главы.");
    if(q) {
     cmnval[7+1]=0;
     cmnval[25-7]=0;
     cmnval[25-8]=0;
     }
}
setFlag(7);
level=cmnval[7+1]
if (level<10) level=10;
if(level<70){
p10=0;
var ppp=0;
for(var i=0;i<6;i++) {
console.log(i+1,anscrw[i+1]);

if (i+1==4 || i+1== 8||i+1== 9||i+1== 7||i+1== 10) ppp=-1; else ppp=0;
document.getElementById("anstext").min=(i+1);
if(checkFlag(i,25-7)) inpword2(anscrw[i+1],ppp);
}

for(var i=7;i<=10;i++){ 
console.log(i,anscrw[i]);
document.getElementById("anstext").min=i;
if (i==4 || i== 8||i== 9||i== 7||i== 10) ppp=-1; else ppp=0;

if(checkFlag(i-7,25-8)) inpword2(anscrw[i],ppp);

}
 

}
console.log(level);
if(level>=95) level=(10+level%10-5)*10

toslide(555,Math.floor(level/10),1);
}}   else window.onload=function(){cmnval=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0];setFlag(7);toslide("",1,1);};

function fun_toTopic(n){

let s=0


// Создаем второй массив из 10 случайных чисел
 secondArray = [];
for (let i = 0; i < 10; i++) {
    secondArray.push(Math.floor(Math.random() * 100));
}
 
// Создаем третий массив - сумму соответствующих элементов
 thirdArray = [];
for (let i = 0; i < 20; i++) {
    thirdArray.push((cmnval[i] + secondArray[i%10])%100);
    s=s+cmnval[i]+secondArray[i%10]
}
s=(s*14323)%100000
s=s.toString().padStart(5, '0');
//console.log(s)
 
s=formatNumbersToString(secondArray)+formatNumbersToString(thirdArray) +s


//history.pushState(null, null, "../"+n+"/?idtmp="+s) ;
gotourl("../"+n+"/index.html?idtmp="+s,false);

}


function setFlag(F,k=0){
if (k==0) {k=Math.floor(F / 6); F=F-k*6;}
cmnval[k] |= Math.pow (2,F)

}


function clrFlag(F,k=0){
if (k==0) {k=Math.floor(F / 6); F=F-k*6;}
cmnval[k] &= ~Math.pow (2,F)

}


function xorFlag(F,k=0){
if (k==0) {k=Math.floor(F / 6); F=F-k*6;}
cmnval[k] ^= Math.pow (2,F)

}


function checkFlag(F,k=0){
if (k==0) {k=Math.floor(F / 6); F=F-k*6;}
return cmnval[k] &Math.pow (2,F);

}
function fun_link(n){
if (n==100) {
level=96;
cmnval[7+1]=level;
fun_toTopic(8);
}else
if (n==61 && level <70) {
level=61;
toslide(11,6,6);
}else
if (n==62 && level <70) {
level=62;
toslide(11,6,6);
}else
if (n==63 && level <70) {
level=63;
toslide(11,6,6);
}else
if (n==64 && level <70) {
level=70;
toslide(11,6,6);
}else
if (n>0&&n<=10) {
inpword(n)
//showShape("ans");
toslide(11,6,6);
}else
if (n==91) {
level=91;
toslide(11,9,9);
} else
if (n==92) {
level=92;
toslide(11,9,9);
} else
if (n==25 && level<25) {
level=25;
toslide(11,2,2);
} else ;
}
before_slide[(1)]=function(){
if (level<10) level=10;
//console.log(level);
}
before_slide[(2)]=function(){
if (level<20) level=20;
}
function fun_menu(n=0){
if(level>=100) level=90+Math.floor(level/10)-5
cmnval[7+1]=level;
fun_toTopic(1);
}
before_slide[(3)]=function(){
if (level<30) level=30;
}
before_slide[(4)]=function(){
if (level<40) level=40;
}
before_slide[(5)]=function(){
if (level<50) level=50;
}
var p10=0;
//hideShape("ans")
before_slide[(6)]=function() {
//hideShape("ans")
if(level<60) level=60;
hideShape("note61")
hideShape("note62")
hideShape("note63")
hideShape("link64")
hideShape("link65")
for(var i=70;i<=81;i++) hideShape("link"+i)
if(level==61) {showShape("note61"); showShape("link71"); showShape("link72"); showShape("link73");}
if(level==62) {showShape("note62"); for(var i=74;i<=81;i++) showShape("link"+i)}
if(level==63) {showShape("note63"); showShape("link70");}
if(p10==10) {showShape("ret3"); hideShape("ret2"); showShape("link64")} else {hideShape("ret3"); showShape("ret2"); showShape("link65")}
}
before_slide[(7)]=function() {
if(level<70) level=70;
}
before_slide[(8)]=function() {
if(level<80) level=80;
}
before_slide[(9)]=function() {
if(level<90) level=90;
hideShape("note91")
hideShape("note92")
hideShape("link92")
hideShape("link93")
if(level>=91) {showShape("note91"); showShape("link92"); }
if(level>=92) {showShape("note92"); showShape("link93"); }
}
before_slide[(10)]=function() {
if(level<100) level=100;
}
before_slide[(11)]=function() {
if(level<110) level=110;
}
